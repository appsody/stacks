module.exports = {
  extends: '@loopback/eslint-config',
  parserOptions: {
    // See https://github.com/typescript-eslint/typescript-eslint/tree/master/packages/parser#configuration
    createDefaultProgram: true,
  },
};
